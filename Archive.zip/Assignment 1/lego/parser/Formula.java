package lego.parser;

public abstract class Formula {
    abstract public String toString ();
} // public abstract class Formula


